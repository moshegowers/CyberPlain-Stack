#include <iostream>
#include "IntStack.h"

void main()
{
	StackExercise::IntStack s;

	// ...
}